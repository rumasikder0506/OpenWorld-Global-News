(function(){
'use strict';
var $=function(s,r){return (r||document).querySelector(s)};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var esc=function(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
var store={get:function(k,d){try{var v=localStorage.getItem('ow_'+k);return v==null?d:JSON.parse(v)}catch(e){return d}},set:function(k,v){try{localStorage.setItem('ow_'+k,JSON.stringify(v))}catch(e){}}};

/* ---------- icons ---------- */
var P={
all:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
bangladesh:'<path d="M5 21V4"/><path d="M5 5h14v11H5"/><circle cx="11.5" cy="10.5" r="2.6"/>',
world:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
politics:'<path d="M3 10l9-6 9 6"/><path d="M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 21h18"/>',
business:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2M3 13h18"/>',
technology:'<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9.5" y="9.5" width="5" height="5"/><path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3"/>',
sports:'<circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18M5.6 5.6c3.5 3 3.5 9.8 0 12.8M18.4 5.6c-3.5 3-3.5 9.8 0 12.8"/>',
entertainment:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 5v14M16 5v14M3 10h5M3 14h5M16 10h5M16 14h5"/>',
health:'<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M12 8v8M8 12h8"/>',
environment:'<path d="M5 19c0-8 5-14 15-14 0 10-6 15-14 15"/><path d="M5 19c3-5 6-8 10-10"/>',
science:'<path d="M9 3h6M10 3v6l-5 9a2 2 0 002 3h10a2 2 0 002-3l-5-9V3"/><path d="M7.5 15h9"/>',
education:'<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11.5V16c0 1.5 2.7 3 6 3s6-1.5 6-3v-4.5"/>',
jobs:'<rect x="4" y="3" width="16" height="18" rx="2"/><circle cx="12" cy="10" r="2.5"/><path d="M8 17c.6-2 2-3 4-3s3.4 1 4 3"/>',
lifestyle:'<path d="M4 9h13v6a5 5 0 01-5 5H9a5 5 0 01-5-5z"/><path d="M17 11h1.5a2.5 2.5 0 010 5H16"/><path d="M8 3v3M12 3v3"/>',
photo:'<path d="M4 8h3l1.5-2h7L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
heart:'<path d="M12 20s-7-4.4-7-10a4 4 0 017-2.6A4 4 0 0119 10c0 5.6-7 10-7 10z"/>',
comment:'<path d="M4 5h16v11H9l-5 4z"/>',
translate:'<path d="M4 5h9M8.5 3v2M6 5c.5 3 2.5 6 6 8M12 5c-.5 3-3 6.5-7 8"/><path d="M13 21l4-10 4 10M14.5 18h5"/>',
menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',
x:'<path d="M6 6l12 12M18 6L6 18"/>',
shield:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
flag:'<path d="M5 21V4M5 5h12l-2 4 2 4H5"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
file:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/>',
video:'<rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3"/>',
pin:'<path d="M12 21s6-5.5 6-11a6 6 0 00-12 0c0 5.5 6 11 6 11z"/><circle cx="12" cy="10" r="2"/>'
};
function ic(n,sz){return '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"'+(sz?' style="width:'+sz+'px;height:'+sz+'px"':'')+'>'+P[n]+'</svg>'}
var CATS=['all','bangladesh','world','politics','business','technology','sports','entertainment','health','environment','science','education','jobs','lifestyle','photo'];
var NAVS=['all','world','bangladesh','technology','politics','business','sports','entertainment','health','jobs'];
var HUE={all:190,bangladesh:150,world:205,politics:255,business:35,technology:215,sports:15,entertainment:320,health:345,environment:140,science:275,education:45,jobs:25,lifestyle:330,photo:200};
var TOPICS=['politics','business','technology','sports','entertainment','health','environment','science','education','jobs','lifestyle'];

/* ---------- languages and interface strings ---------- */
var LANGS=[['en','English','English'],['bn','Bengali','বাংলা'],['ar','Arabic','العربية'],['zh','Chinese','中文'],['ja','Japanese','日本語'],['ko','Korean','한국어'],['hi','Hindi','हिन्दी'],['ur','Urdu','اردو'],['es','Spanish','Español'],['fr','French','Français'],['de','German','Deutsch'],['pt','Portuguese','Português'],['ru','Russian','Русский'],['it','Italian','Italiano'],['tr','Turkish','Türkçe'],['id','Indonesian','Bahasa Indonesia'],['nl','Dutch','Nederlands'],['sw','Swahili','Kiswahili'],['vi','Vietnamese','Tiếng Việt'],['th','Thai','ไทย'],['fa','Persian','فارسی'],['pl','Polish','Polski']];
var RTL=['ar','ur','fa'];
var KEYS='home,world,bangladesh,technology,politics,business,sports,entertainment,health,jobs,environment,science,education,lifestyle,photo,all,search,searchPh,login,signup,logout,publish,breaking,featured,latest,trending,community,countries,categories,like,comment,translate,original,anon,language,stories,tagline'.split(',');
function mk(s){var a=s.split('|');var o={};KEYS.forEach(function(k,i){o[k]=a[i]});return o}
var I18N={
en:mk('Home|World|Bangladesh|Technology|Politics|Business|Sports|Entertainment|Health|Jobs|Environment|Science|Education|Lifestyle|Photo & Video|All News|Search|Search stories, countries, topics|Login|Sign Up|Log out|Publish a Story|Breaking|Featured News|Latest News|Trending News|Community Reports|Popular Countries|News Categories|Like|Comment|Translate|Original News|Anonymous Reporter|Display language|stories|Every Voice. Every Story. Every Corner of the World.'),
bn:mk('হোম|বিশ্ব|বাংলাদেশ|প্রযুক্তি|রাজনীতি|ব্যবসা|খেলা|বিনোদন|স্বাস্থ্য|চাকরি|পরিবেশ|বিজ্ঞান|শিক্ষা|জীবনধারা|ছবি ও ভিডিও|সব খবর|অনুসন্ধান|খবর, দেশ বা বিষয় খুঁজুন|লগইন|নিবন্ধন|লগআউট|খবর প্রকাশ করুন|ব্রেকিং|বিশেষ খবর|সর্বশেষ খবর|জনপ্রিয় খবর|কমিউনিটি রিপোর্ট|জনপ্রিয় দেশ|খবরের বিভাগ|পছন্দ|মন্তব্য|অনুবাদ|মূল খবর|অজ্ঞাতনামা প্রতিবেদক|ভাষা|টি খবর|প্রতিটি কণ্ঠ। প্রতিটি গল্প। বিশ্বের প্রতিটি প্রান্ত।'),
ar:mk('الرئيسية|العالم|بنغلاديش|التقنية|السياسة|الأعمال|الرياضة|الترفيه|الصحة|وظائف|البيئة|العلوم|التعليم|نمط الحياة|صور وفيديو|كل الأخبار|بحث|ابحث عن أخبار أو دول أو مواضيع|تسجيل الدخول|إنشاء حساب|تسجيل الخروج|انشر خبراً|عاجل|أخبار مميزة|آخر الأخبار|الأكثر رواجاً|تقارير المجتمع|الدول الأكثر حضوراً|أقسام الأخبار|إعجاب|تعليق|ترجمة|الخبر الأصلي|مراسل مجهول|لغة العرض|خبراً|كل صوت. كل قصة. كل ركن في العالم.'),
es:mk('Inicio|Mundo|Bangladés|Tecnología|Política|Economía|Deportes|Espectáculos|Salud|Empleo|Medio ambiente|Ciencia|Educación|Estilo de vida|Foto y vídeo|Todas las noticias|Buscar|Busca noticias, países o temas|Iniciar sesión|Registrarse|Cerrar sesión|Publicar una noticia|Última hora|Noticias destacadas|Últimas noticias|Tendencias|Reportes de la comunidad|Países populares|Categorías|Me gusta|Comentar|Traducir|Noticia original|Reportero anónimo|Idioma de la interfaz|noticias|Cada voz. Cada historia. Cada rincón del mundo.'),
fr:mk('Accueil|Monde|Bangladesh|Technologie|Politique|Économie|Sport|Divertissement|Santé|Emploi|Environnement|Sciences|Éducation|Art de vivre|Photo et vidéo|Toutes les actualités|Rechercher|Rechercher des articles, pays ou sujets|Connexion|Inscription|Déconnexion|Publier un article|Dernière minute|À la une|Dernières actualités|Tendances|Reportages citoyens|Pays populaires|Catégories|J’aime|Commenter|Traduire|Article original|Reporter anonyme|Langue d’affichage|articles|Chaque voix. Chaque histoire. Chaque coin du monde.'),
hi:mk('होम|दुनिया|बांग्लादेश|तकनीक|राजनीति|कारोबार|खेल|मनोरंजन|स्वास्थ्य|नौकरियां|पर्यावरण|विज्ञान|शिक्षा|जीवनशैली|फोटो और वीडियो|सभी खबरें|खोजें|खबरें, देश या विषय खोजें|लॉगिन|साइन अप|लॉग आउट|खबर प्रकाशित करें|ब्रेकिंग|खास खबरें|ताज़ा खबरें|ट्रेंडिंग|कम्युनिटी रिपोर्ट|लोकप्रिय देश|खबरों की श्रेणियां|पसंद|टिप्पणी|अनुवाद|मूल खबर|गुमनाम रिपोर्टर|प्रदर्शन भाषा|खबरें|हर आवाज़। हर कहानी। दुनिया का हर कोना।')
};
var COUNTRIES=[['BD','Bangladesh'],['IN','India'],['PK','Pakistan'],['LK','Sri Lanka'],['NP','Nepal'],['US','United States'],['CA','Canada'],['MX','Mexico'],['BR','Brazil'],['AR','Argentina'],['GB','United Kingdom'],['DE','Germany'],['FR','France'],['ES','Spain'],['IT','Italy'],['TR','Türkiye'],['RU','Russia'],['EG','Egypt'],['NG','Nigeria'],['KE','Kenya'],['ZA','South Africa'],['SA','Saudi Arabia'],['AE','United Arab Emirates'],['CN','China'],['JP','Japan'],['KR','South Korea'],['ID','Indonesia'],['VN','Vietnam'],['TH','Thailand'],['AU','Australia']];
function cname(c){for(var i=0;i<COUNTRIES.length;i++)if(COUNTRIES[i][0]===c)return COUNTRIES[i][1];return c}

/* ---------- sample stories ---------- */
var A=[
{id:1,cat:'environment',cc:'BD',loc:'Sirajganj',m:25,likes:214,author:'rivervoice_bd',community:1,feat:1,breaking:1,t:'Riverbank erosion forces 300 families to leave Sirajganj villages',s:'Residents say the Jamuna has taken homes and two primary schools since August. Families are staying in temporary shelters and asking for a resettlement plan before winter.'},
{id:2,cat:'health',cc:'KE',loc:'Turkana County',m:70,likes:168,author:'clinic_notes',breaking:1,t:'Mobile clinics cut maternal care waiting times in Turkana County',s:'Community health workers report that visits by mobile clinics have shortened waits for antenatal checks from several weeks to a few days. Supplies of iron tablets remain irregular.'},
{id:3,cat:'technology',cc:'JP',loc:'Tokyo',m:120,likes:97,author:'kenji_makes',t:'Tokyo startup tests solid-state battery pack for delivery bikes',s:'A small team says its prototype pack charges to 80 percent in 12 minutes in bench tests. Road trials with three courier companies begin next month.'},
{id:4,cat:'environment',cc:'BR',loc:'Xingu basin',m:190,likes:342,anon:1,community:1,photo:1,feat:1,t:'Community patrols document illegal logging along a Xingu tributary',s:'Volunteers recorded GPS points and photographs of fresh clearings over six weeks. The files have been passed to a regional environmental prosecutor.'},
{id:5,cat:'politics',cc:'DE',loc:'Berlin',m:45,likes:128,author:'civicdesk',breaking:1,feat:1,t:'Berlin district council votes to publish all contracts above €50,000',s:'The measure passed 31 to 12 after a public hearing. Contracts will appear in an online register within 30 days of signing.'},
{id:6,cat:'education',cc:'BD',loc:'Dhaka',m:300,likes:256,author:'tania_r',community:1,t:'Dhaka school opens free evening coding classes for girls',s:'Sixty students from nearby neighbourhoods signed up in the first week. Volunteers from local software firms teach two evenings a week.'},
{id:7,cat:'business',cc:'IN',loc:'Pune',m:380,likes:89,author:'mandi_diary',t:'Pune street vendors adopt shared QR payments and report steadier sales',s:'A cooperative of 140 vendors now uses one payment code per lane. Members say fewer customers walk away for lack of change.'},
{id:8,cat:'environment',cc:'MX',loc:'Iztapalapa, Mexico City',m:55,likes:301,anon:1,community:1,t:'Residents report unlicensed dumping beside the Iztapalapa water canal',s:'Neighbours describe night-time truck deliveries over the past month and have sent photographs to the city water authority. No response has been published yet.'},
{id:9,cat:'sports',cc:'EG',loc:'Cairo',m:520,likes:77,author:'goalline_cairo',photo:1,t:'Cairo youth league adds a wheelchair football division',s:'Eight teams will play in the new division from January. Organisers are raising funds for match chairs through local clubs.'},
{id:10,cat:'science',cc:'CA',loc:'Halifax',m:610,likes:64,author:'tidal_lab',t:'Halifax researchers map how much carbon seaweed farms absorb',s:'A two-year survey of five farms found large differences between species. The team plans to publish its measurements as open data.'},
{id:11,cat:'jobs',cc:'ID',loc:'Jakarta',m:700,likes:143,author:'karir_id',t:'Jakarta job fair lists 4,000 remote openings, most without degree requirements',s:'Employers in customer support, design and data entry took part. Organisers say a second fair for regional cities is planned.'},
{id:12,cat:'politics',cc:'BD',loc:'Rangpur',m:15,likes:52,author:'upazila_watch',breaking:1,t:'Rangpur union council livestreams its budget meeting for the first time',s:'Around 400 residents watched online as members discussed road repair and drainage spending. A recording will be kept at the council office.'}
];
var TR={
1:{es:{t:'La erosión de la ribera obliga a 300 familias a abandonar aldeas de Sirajganj',s:'Los vecinos dicen que el Jamuna se ha llevado viviendas y dos escuelas primarias desde agosto. Las familias viven en refugios temporales y piden un plan de reasentamiento antes del invierno.'},bn:{t:'নদীভাঙনে সিরাজগঞ্জের ৩০০ পরিবার গ্রাম ছাড়তে বাধ্য হচ্ছে',s:'বাসিন্দারা জানান, আগস্ট থেকে যমুনা বহু ঘরবাড়ি ও দুটি প্রাথমিক বিদ্যালয় গ্রাস করেছে। পরিবারগুলো অস্থায়ী আশ্রয়ে থাকছে এবং শীতের আগে পুনর্বাসন পরিকল্পনা চাইছে।'}},
2:{es:{t:'Las clínicas móviles reducen las esperas de atención materna en el condado de Turkana',s:'Trabajadores de salud comunitarios informan de que las visitas de clínicas móviles han reducido la espera para controles prenatales de varias semanas a pocos días. El suministro de tabletas de hierro sigue siendo irregular.'},bn:{t:'টুরকানা কাউন্টিতে ভ্রাম্যমাণ ক্লিনিকে মাতৃসেবার অপেক্ষা কমেছে',s:'কমিউনিটি স্বাস্থ্যকর্মীরা জানান, ভ্রাম্যমাণ ক্লিনিকের কারণে গর্ভকালীন পরীক্ষার অপেক্ষা কয়েক সপ্তাহ থেকে কমে কয়েক দিনে নেমেছে। আয়রন ট্যাবলেটের সরবরাহ এখনও অনিয়মিত।'}},
3:{es:{t:'Una startup de Tokio prueba una batería de estado sólido para bicicletas de reparto',s:'Un pequeño equipo afirma que su prototipo se carga al 80 por ciento en 12 minutos en pruebas de laboratorio. Las pruebas en carretera con tres empresas de mensajería comienzan el mes próximo.'},bn:{t:'টোকিওর স্টার্টআপ ডেলিভারি বাইকের জন্য সলিড-স্টেট ব্যাটারি পরীক্ষা করছে',s:'একটি ছোট দল জানায়, ল্যাব পরীক্ষায় তাদের প্রোটোটাইপ ১২ মিনিটে ৮০ শতাংশ চার্জ হয়। আগামী মাসে তিনটি কুরিয়ার প্রতিষ্ঠানের সঙ্গে সড়কে পরীক্ষা শুরু হবে।'}},
4:{es:{t:'Patrullas comunitarias documentan tala ilegal a lo largo de un afluente del Xingu',s:'Voluntarios registraron puntos GPS y fotografías de nuevos desmontes durante seis semanas. Los archivos se entregaron a un fiscal ambiental regional.'},bn:{t:'জিংগু নদীর শাখা বরাবর অবৈধ গাছ কাটার প্রমাণ সংগ্রহ করছে স্থানীয় টহল দল',s:'স্বেচ্ছাসেবকরা ছয় সপ্তাহ ধরে নতুন সাফ করা জমির জিপিএস পয়েন্ট ও ছবি নথিভুক্ত করেছেন। ফাইলগুলো একজন আঞ্চলিক পরিবেশ প্রসিকিউটরের কাছে জমা দেওয়া হয়েছে।'}},
5:{es:{t:'El consejo de un distrito de Berlín vota publicar todos los contratos superiores a 50.000 €',s:'La medida se aprobó por 31 votos a 12 tras una audiencia pública. Los contratos aparecerán en un registro en línea en un plazo de 30 días desde su firma.'},bn:{t:'বার্লিনের একটি জেলা পরিষদ ৫০ হাজার ইউরোর বেশি সব চুক্তি প্রকাশের পক্ষে ভোট দিয়েছে',s:'জনশুনানির পর প্রস্তাবটি ৩১–১২ ভোটে পাস হয়েছে। স্বাক্ষরের ৩০ দিনের মধ্যে চুক্তিগুলো অনলাইন নিবন্ধে প্রকাশ করা হবে।'}},
6:{es:{t:'Una escuela de Daca abre clases nocturnas gratuitas de programación para niñas',s:'Sesenta estudiantes de barrios cercanos se inscribieron en la primera semana. Voluntarios de empresas de software locales dan clase dos tardes por semana.'},bn:{t:'ঢাকার একটি স্কুলে মেয়েদের জন্য বিনামূল্যে সান্ধ্যকালীন কোডিং ক্লাস শুরু',s:'প্রথম সপ্তাহেই আশপাশের এলাকা থেকে ষাটজন শিক্ষার্থী নাম লিখিয়েছে। স্থানীয় সফটওয়্যার প্রতিষ্ঠানের স্বেচ্ছাসেবকরা সপ্তাহে দুই সন্ধ্যায় পড়ান।'}},
7:{es:{t:'Vendedores ambulantes de Pune adoptan pagos QR compartidos y reportan ventas más estables',s:'Una cooperativa de 140 vendedores usa ahora un código de pago por calle. Los miembros dicen que menos clientes se van por falta de cambio.'},bn:{t:'পুনের ফুটপাথ ব্যবসায়ীরা যৌথ কিউআর পেমেন্ট চালু করে স্থিতিশীল বিক্রির কথা জানাচ্ছেন',s:'১৪০ জন ব্যবসায়ীর একটি সমবায় এখন প্রতিটি গলিতে একটি করে পেমেন্ট কোড ব্যবহার করছে। সদস্যরা বলছেন, খুচরো না থাকায় ক্রেতা ফিরে যাওয়ার ঘটনা কমেছে।'}},
8:{es:{t:'Vecinos denuncian vertidos sin licencia junto al canal de agua de Iztapalapa',s:'Los vecinos describen entregas nocturnas de camiones durante el último mes y enviaron fotografías a la autoridad del agua de la ciudad. Aún no se ha publicado ninguna respuesta.'},bn:{t:'ইজতাপালাপা জলখালের পাশে অনুমোদনহীন বর্জ্য ফেলার অভিযোগ বাসিন্দাদের',s:'প্রতিবেশীরা গত এক মাস ধরে রাতে ট্রাকে বর্জ্য আনার কথা জানিয়েছেন এবং নগর পানি কর্তৃপক্ষকে ছবি পাঠিয়েছেন। এখনও কোনো জবাব প্রকাশিত হয়নি।'}},
9:{es:{t:'La liga juvenil de El Cairo crea una división de fútbol en silla de ruedas',s:'Ocho equipos jugarán en la nueva división a partir de enero. Los organizadores reúnen fondos para sillas de juego a través de clubes locales.'},bn:{t:'কায়রোর যুব লিগে হুইলচেয়ার ফুটবল বিভাগ যুক্ত হলো',s:'জানুয়ারি থেকে নতুন বিভাগে আটটি দল খেলবে। আয়োজকরা স্থানীয় ক্লাবের মাধ্যমে ম্যাচ-চেয়ারের জন্য তহবিল সংগ্রহ করছেন।'}},
10:{es:{t:'Investigadores de Halifax miden cuánto carbono absorben las granjas de algas',s:'Un estudio de dos años en cinco granjas halló grandes diferencias entre especies. El equipo planea publicar sus mediciones como datos abiertos.'},bn:{t:'হ্যালিফ্যাক্সের গবেষকরা সামুদ্রিক শৈবাল খামারের কার্বন শোষণ মানচিত্রে তুলছেন',s:'পাঁচটি খামারে দুই বছরের জরিপে প্রজাতিভেদে বড় পার্থক্য পাওয়া গেছে। দলটি তাদের পরিমাপ উন্মুক্ত তথ্য হিসেবে প্রকাশ করতে চায়।'}},
11:{es:{t:'Una feria de empleo en Yakarta ofrece 4.000 puestos remotos, la mayoría sin exigir título',s:'Participaron empresas de atención al cliente, diseño e ingreso de datos. Los organizadores dicen que se planea una segunda feria para ciudades regionales.'},bn:{t:'জাকার্তার চাকরি মেলায় ৪ হাজার রিমোট পদ, বেশিরভাগে ডিগ্রি লাগবে না',s:'গ্রাহকসেবা, ডিজাইন ও ডেটা এন্ট্রি খাতের নিয়োগকর্তারা অংশ নিয়েছেন। আয়োজকরা জানান, আঞ্চলিক শহরগুলোর জন্য দ্বিতীয় একটি মেলার পরিকল্পনা আছে।'}},
12:{es:{t:'Un consejo de unión de Rangpur transmite en directo su reunión presupuestaria por primera vez',s:'Unas 400 personas siguieron en línea cómo los miembros debatían el gasto en reparación de carreteras y drenaje. Se guardará una grabación en la oficina del consejo.'},bn:{t:'প্রথমবারের মতো বাজেট সভা সরাসরি সম্প্রচার করল রংপুরের এক ইউনিয়ন পরিষদ',s:'প্রায় ৪০০ বাসিন্দা অনলাইনে দেখেছেন সদস্যরা সড়ক মেরামত ও নিষ্কাশন ব্যয় নিয়ে আলোচনা করছেন। পরিষদ কার্যালয়ে একটি রেকর্ডিং রাখা হবে।'}}
};
var SEED_COMMENTS={1:[{n:'sumon_k',t:'Our ward lost its market road last week. The shelters need clean water more than anything.',m:18}],4:[{n:'forest_eyes',t:'Thank you for documenting this. Please keep the file dates intact.',m:140},{n:'lucia_m',t:'Is there a public case number yet?',m:95}],6:[{n:'mehjabin',t:'Is there a waiting list for the next batch?',m:210}]};

/* ---------- state ---------- */
var S={lang:store.get('lang',null)||'en',tLang:store.get('tlang',null),cat:'all',q:'',liked:store.get('liked',[]),tr:{},comments:{},user:store.get('user',null),openId:null,pick:null,bi:0,files:[],reviewed:false};
A.forEach(function(a){a.at=Date.now()-a.m*60000;S.comments[a.id]=(SEED_COMMENTS[a.id]||[]).map(function(c){return {n:c.n,t:c.t,at:Date.now()-c.m*60000}})});
var nextId=100;
function T(k){var d=I18N[S.lang];return (d&&d[k])||I18N.en[k]}
function lname(code){for(var i=0;i<LANGS.length;i++)if(LANGS[i][0]===code)return LANGS[i]}
function mins(a){return Math.max(0,Math.round((Date.now()-a.at)/60000))}
function ago(a){var m=mins(a);if(m<1)return 'Just now';if(m<60)return m+' min ago';if(m<1440)return Math.floor(m/60)+' h ago';return Math.floor(m/1440)+' d ago'}
function inCat(a,c){if(c==='all')return true;if(c==='bangladesh')return a.cc==='BD';if(c==='world')return a.cc!=='BD';if(c==='photo')return !!a.photo;return a.cat===c}
function likes(a){return a.likes+(S.liked.indexOf(a.id)>-1?1:0)}
function byId(id){for(var i=0;i<A.length;i++)if(A[i].id===id)return A[i]}
function toast(msg){var t=$('#toast');t.textContent=msg;t.hidden=false;clearTimeout(toast.h);toast.h=setTimeout(function(){t.hidden=true},4200)}

/* ---------- chrome ---------- */
function applyLang(){
  document.documentElement.lang=S.lang;
  document.documentElement.dir=RTL.indexOf(S.lang)>-1?'rtl':'ltr';
  $$('[data-i18n]').forEach(function(e){e.textContent=T(e.getAttribute('data-i18n'))});
  $$('[data-i18n-ph]').forEach(function(e){e.placeholder=T(e.getAttribute('data-i18n-ph'))});
  var L=lname(S.lang);
  var lb=ic('world')+'<span>'+esc(L[2])+'</span>';
  $('#langBtn').innerHTML=lb;$('#langBtnM').innerHTML=ic('world')+'<span class="mono">'+S.lang.toUpperCase()+'</span>';
  $('#langBtn').setAttribute('aria-label',T('language')+': '+L[1]);
  $('[data-act=menu]').innerHTML=ic('menu');
  $('.x').innerHTML=ic('x');
  $('#fab').innerHTML=ic('plus')+'<span>'+esc(T('publish'))+'</span>';
}
function renderNav(){
  var h=NAVS.map(function(c){return '<button data-act="cat" data-cat="'+c+'" aria-current="'+(S.cat===c&&!S.q)+'">'+esc(T(c==='all'?'home':c))+'</button>'}).join('');
  $('#nav').innerHTML=h;$('#drawerNav').innerHTML=h;
  $('#strip').innerHTML=CATS.map(function(c){return '<button class="chip" data-act="cat" data-cat="'+c+'" aria-pressed="'+(S.cat===c&&!S.q)+'">'+ic(c)+esc(T(c))+'</button>'}).join('');
  var u=S.user;
  var tools=(u?'<span class="btn ghost" style="cursor:default">'+ic('shield')+esc(u.username)+'</span><button class="btn" data-act="logout">'+esc(T('logout'))+'</button>':'<button class="btn" data-act="login">'+esc(T('login'))+'</button><button class="btn" data-act="signup">'+esc(T('signup'))+'</button>')+'<button class="btn primary" data-act="publish">'+esc(T('publish'))+'</button>';
  $('#drawerTools').innerHTML=tools;
  var d=$('.tools.desk');
  d.innerHTML='<button class="btn" id="langBtn" data-act="lang" aria-haspopup="dialog"></button>'+(u?'<span class="btn ghost" style="cursor:default">'+ic('shield')+esc(u.username)+'</span><button class="btn ghost" data-act="logout">'+esc(T('logout'))+'</button>':'<button class="btn ghost" data-act="login">'+esc(T('login'))+'</button><button class="btn" data-act="signup">'+esc(T('signup'))+'</button>')+'<button class="btn primary" data-act="publish">'+ic('plus')+'<span>'+esc(T('publish'))+'</span></button>';
  var L=lname(S.lang);$('#langBtn').innerHTML=ic('world')+'<span>'+esc(L[2])+'</span>';$('#langBtn').setAttribute('aria-label',T('language')+': '+L[1]);
}
var bTimer;
function renderBreaking(){
  var list=A.filter(function(a){return a.breaking}).sort(function(a,b){return b.at-a.at});
  var el=$('#breaking');if(!list.length){el.hidden=true;return}
  el.hidden=false;
  function show(){var a=list[S.bi%list.length];el.innerHTML='<div class="wrap"><span class="lab">'+esc(T('breaking'))+'</span><button class="hl" data-act="open" data-id="'+a.id+'">'+esc(S.tr[a.id]&&TR[a.id][S.tr[a.id]]?TR[a.id][S.tr[a.id]].t:a.t)+'</button><span class="ct">'+((S.bi%list.length)+1)+'/'+list.length+'</span></div>'}
  show();clearInterval(bTimer);
  bTimer=setInterval(function(){if(el.matches(':hover')||el.contains(document.activeElement))return;S.bi++;show()},6000);
}

/* ---------- cards ---------- */
function bylineHTML(a){
  if(a.anon)return '<span class="av" style="background:var(--muted)">'+ic('shield',13)+'</span><span>'+esc(T('anon'))+'</span>';
  var av=a.avatar?'<img alt="" src="'+a.avatar+'">':esc(a.author.charAt(0).toUpperCase());
  return '<span class="av">'+av+'</span><span>'+esc(a.author)+'</span>';
}
function actionsHTML(a){
  var liked=S.liked.indexOf(a.id)>-1;
  return '<div class="actions"><button class="act" data-act="like" data-id="'+a.id+'" aria-pressed="'+liked+'" aria-label="'+esc(T('like'))+'">'+ic('heart')+'<span>'+likes(a)+'</span></button>'+
  '<button class="act" data-act="open" data-id="'+a.id+'" data-focus="comment" aria-label="'+esc(T('comment'))+'">'+ic('comment')+'<span>'+S.comments[a.id].length+'</span></button>'+
  '<button class="act" data-act="translate" data-id="'+a.id+'">'+ic('translate')+'<span>'+esc(T('translate'))+'</span></button></div>';
}
function transBox(a){
  var l=S.tr[a.id];if(!l)return '';
  return '<div class="trans"><span>Machine-generated translation to '+esc(lname(l)[1])+'. It may contain errors.</span><button data-act="original" data-id="'+a.id+'">'+esc(T('original'))+'</button></div>';
}
function pick(a){var l=S.tr[a.id];return l&&TR[a.id]&&TR[a.id][l]?TR[a.id][l]:{t:a.t,s:a.s}}
function card(a,big){
  var p=pick(a);
  return '<article class="card'+(big?' big':'')+'"><button class="tile" data-act="open" data-id="'+a.id+'" style="--h:'+HUE[a.cat]+'" aria-label="Open story">'+ic(a.cat)+'<span class="cc">'+a.cc+'</span>'+(a.photo?'<span class="mt">'+ic('photo',14)+'</span>':'')+'</button>'+
  '<div class="meta"><span class="cat">'+esc(T(a.cat))+'</span><span>'+esc(a.loc)+'</span><span>'+ago(a)+'</span></div>'+
  '<h3><button class="hl" data-act="open" data-id="'+a.id+'">'+esc(p.t)+'</button></h3>'+
  '<p class="sum">'+esc(p.s)+'</p>'+transBox(a)+
  '<div class="by">'+bylineHTML(a)+(a.community?'<span class="tag">'+esc(T('community'))+'</span>':'')+'</div>'+actionsHTML(a)+'</article>';
}
function sec(title,right,inner){return '<section class="sec"><div class="sec-h"><h2>'+esc(title)+'</h2>'+(right?'<span>'+right+'</span>':'')+'</div>'+inner+'</section>'}

function renderMain(){
  var m=$('#main');var q=S.q.toLowerCase();
  if(q){
    var r=A.filter(function(a){return (a.t+' '+a.s+' '+a.loc+' '+cname(a.cc)+' '+a.cat).toLowerCase().indexOf(q)>-1});
    m.innerHTML=sec(T('search')+': '+S.q,r.length+' '+T('stories'),r.length?'<div class="grid3">'+r.map(function(a){return card(a)}).join('')+'</div>':'<div class="empty">No stories match &ldquo;'+esc(S.q)+'&rdquo;. Try a country name or a topic.</div>');
    return;
  }
  var list=A.filter(function(a){return inCat(a,S.cat)}).sort(function(a,b){return b.at-a.at});
  var out='';
  if(!list.length){
    out+=sec(T(S.cat),'0 '+T('stories'),'<div class="empty"><p>No stories in this category yet.</p><button class="btn primary" data-act="publish">'+esc(T('publish'))+'</button></div>');
  }else{
    var f=list.filter(function(a){return a.feat});
    f=(f.length<3?f.concat(list.filter(function(a){return !a.feat})):f).slice(0,3);
    var latest=list.filter(function(a){return f.indexOf(a)<0});
    var trend=A.slice().sort(function(a,b){return (likes(b)+S.comments[b.id].length*3)-(likes(a)+S.comments[a.id].length*3)}).slice(0,5);
    var cn={};A.forEach(function(a){cn[a.cc]=(cn[a.cc]||0)+1});
    var cl=Object.keys(cn).sort(function(a,b){return cn[b]-cn[a]||(a<b?-1:1)}).slice(0,6);
    var feat='<div class="hero"><div>'+card(f[0],true)+(f.length>1?'<div class="subfeat">'+f.slice(1).map(function(a){return card(a)}).join('')+'</div>':'')+'</div>'+
      '<aside class="rail"><section><div class="sec-h"><h2>'+esc(T('trending'))+'</h2></div><ol class="rank">'+trend.map(function(a,i){return '<li><span class="n">'+(i+1)+'</span><div><button class="hl" data-act="open" data-id="'+a.id+'">'+esc(pick(a).t)+'</button><small>'+a.cc+' · '+likes(a)+' likes · '+S.comments[a.id].length+' comments</small></div></li>'}).join('')+'</ol></section>'+
      '<section><div class="sec-h"><h2>'+esc(T('countries'))+'</h2></div><ul class="ctry">'+cl.map(function(c){return '<li><button data-act="search" data-q="'+esc(cname(c))+'"><span class="code">'+c+'</span><span class="nm">'+esc(cname(c))+'</span><span class="ct">'+cn[c]+' '+esc(T('stories'))+'</span></button></li>'}).join('')+'</ul></section></aside></div>';
    out+=sec(T('featured'),S.cat==='all'?'':esc(T(S.cat)),feat).replace('<section class="sec">','<section class="sec" style="margin-top:0">');
    if(latest.length)out+=sec(T('latest'),latest.length+' '+T('stories'),'<div class="grid3">'+latest.map(function(a){return card(a)}).join('')+'</div>');
  }
  var com=A.filter(function(a){return a.community&&inCat(a,S.cat)}).sort(function(a,b){return b.at-a.at});
  out+='<div class="band"><div class="wrap" style="padding:0">'+sec(T('community'),com.length+' '+T('stories'),'<div class="callout">'+ic('shield',20)+'<div>Reports from readers on the ground. Anonymous reports show no name or photo. No platform can promise absolute anonymity, so strip location data from photos before you upload.</div></div>'+(com.length?'<div class="com-grid">'+com.map(function(a){return card(a)}).join('')+'</div>':'<div class="empty">No community reports in this category yet.</div>'))+'</div></div>';
  var tiles=CATS.map(function(c){var n=A.filter(function(a){return inCat(a,c)}).length;return '<button class="cat-tile" data-act="cat" data-cat="'+c+'">'+ic(c)+'<b>'+esc(T(c))+'</b><small>'+n+' '+esc(T('stories'))+'</small></button>'}).join('');
  out+='<div style="margin-top:48px">'+sec(T('categories'),'',' <div class="cats">'+tiles+'</div>')+'</div>';
  m.innerHTML=out;
}
function renderAll(){renderNav();renderBreaking();renderMain()}

/* ---------- modal ---------- */
var lastFocus=null;
function openModal(html,cls,keepFocus){
  var o=$('#overlay');if(o.hidden)lastFocus=document.activeElement;
  $('#modal').className='modal '+(cls||'');$('#modalBody').innerHTML=html;o.hidden=false;document.body.classList.add('lock');
  if(!keepFocus){var f=$('#modalBody input,#modalBody textarea,#modalBody select');(f||$('#modal')).focus({preventScroll:true})}
  o.scrollTop=0;
}
function closeModal(){
  $('#overlay').hidden=true;document.body.classList.remove('lock');S.openId=null;S.pick=null;
  if(lastFocus&&lastFocus.focus&&document.contains(lastFocus))lastFocus.focus();
}
function fieldHTML(id,label,type,extra){return '<div class="field"><label for="'+id+'">'+label+'</label><input id="'+id+'" name="'+id+'" type="'+type+'" '+(extra||'')+'></div>'}
function countryOpts(sel){return COUNTRIES.map(function(c){return '<option value="'+c[0]+'"'+(c[0]===sel?' selected':'')+'>'+esc(c[1])+'</option>'}).join('')}

/* article modal */
function showArticle(id,focusComment){
  var a=byId(id);if(!a)return;S.openId=id;
  var p=pick(a);var cm=S.comments[id];
  var html='<div class="meta"><span class="cat">'+esc(T(a.cat))+'</span><span>'+ic('pin',12)+' '+esc(a.loc)+', '+esc(cname(a.cc))+'</span><span>'+ago(a)+'</span></div>'+
  '<h2 style="margin-top:8px;font-size:30px">'+esc(p.t)+'</h2>'+
  '<div class="by" style="margin:10px 0 14px">'+bylineHTML(a)+(a.community?'<span class="tag">'+esc(T('community'))+'</span>':'')+'</div>'+
  '<div class="tile" style="--h:'+HUE[a.cat]+';margin-bottom:16px">'+ic(a.cat)+'<span class="cc">'+a.cc+'</span></div>'+
  transBox(a)+'<p class="body-text">'+esc(p.s)+'</p>'+
  (a.files&&a.files.length?'<h4>Attachments</h4><ul class="files">'+a.files.map(function(f){return '<li><span class="th">'+ic(f.type==='pdf'?'file':f.type==='video'?'video':'photo')+'</span><span class="nm">'+esc(f.name)+'</span><span></span></li>'}).join('')+'</ul>':'')+
  actionsHTML(a)+
  '<div style="display:flex;justify-content:flex-end"><button class="btn ghost sm" data-act="report" data-id="'+id+'">'+ic('flag')+'Report</button></div>'+
  '<h4>'+esc(T('comment'))+' ('+cm.length+')</h4><div id="cmList">'+(cm.length?cm.map(function(c){return '<div class="cm"><b>'+esc(c.n)+'</b><small>'+ago({at:c.at})+'</small><p>'+esc(c.t)+'</p></div>'}).join(''):'<p class="lead">No comments yet. Start the conversation.</p>')+'</div>'+
  '<form id="cmForm" data-id="'+id+'" style="margin-top:12px"><div class="field"><label for="cmText">'+(S.user?'Comment as '+esc(S.user.username):'Log in to comment')+'</label><textarea id="cmText" style="min-height:80px" maxlength="1000" placeholder="Share what you know. Be respectful."></textarea></div><div class="modal-foot"><button class="btn primary" type="submit">'+esc(T('comment'))+'</button></div></form>';
  openModal(html,'',true);
  if(focusComment)setTimeout(function(){var t=$('#cmText');if(t)t.focus()},30);else $('#modal').focus({preventScroll:true});
}

/* language picker */
function showPicker(mode,id){
  S.pick={mode:mode,id:id,sel:mode==='display'?S.lang:null,back:S.openId};
  var tm=mode==='translate';
  openModal('<h2>'+esc(tm?T('translate'):T('language'))+'</h2><p class="lead">'+(tm?'Choose a language, then press Translate. The original text is always kept.':'The interface changes right away. Your choice is saved on this device.')+'</p>'+
  '<div class="field"><label class="sr" for="langSearch">Search languages</label><input id="langSearch" type="search" placeholder="Search languages" autocomplete="off"></div><ul class="langlist" id="langList" role="listbox"></ul>'+
  (tm?'<p class="lead" style="margin-top:12px;font-size:13px">Preview note: this build holds sample Spanish and Bengali translations. Other languages connect to the server-side translation API in Phase 7.</p><div class="modal-foot"><button class="btn" data-act="pickcancel">Cancel</button><button class="btn primary" id="doTranslate" data-act="dotranslate" disabled>'+esc(T('translate'))+'</button></div>':''),'sm');
  renderLangList();
}
function renderLangList(){
  var q=(($('#langSearch')||{}).value||'').toLowerCase();var p=S.pick;if(!p)return;
  var items=LANGS.filter(function(l){return (l[1]+' '+l[2]).toLowerCase().indexOf(q)>-1});
  $('#langList').innerHTML=items.length?items.map(function(l){
    var tag=p.mode==='display'?(I18N[l[0]]?'':'UI soon'):(l[0]==='es'||l[0]==='bn'?'':'API Phase 7');
    if(p.mode==='translate'&&S.tLang===l[0])tag=(tag?tag+' · ':'')+'last used';
    return '<li><button role="option" data-act="pl" data-l="'+l[0]+'" aria-selected="'+(p.sel===l[0])+'"><span>'+esc(l[2])+' <small>'+esc(l[1])+'</small></span><small>'+tag+'</small></button></li>'}).join(''):'<li style="padding:12px" class="lead">No language matches.</li>';
  var b=$('#doTranslate');if(b)b.disabled=!p.sel;
}
function setLang(code){
  S.lang=code;store.set('lang',code);applyLang();renderAll();
  if(!I18N[code])toast('The interface is not translated into '+lname(code)[1]+' yet, so it shows English. Story translation still works.');
}

/* auth */
function showAuth(kind,note){
  if(kind==='login'){
    openModal('<h2>'+esc(T('login'))+'</h2><p class="lead">Welcome back.</p>'+(note?'<p class="note">'+esc(note)+'</p>':'')+'<form id="loginForm" novalidate>'+fieldHTML('lgEmail','Email','email','autocomplete="email" required')+fieldHTML('lgPass','Password','password','autocomplete="current-password" required')+'<p class="err" id="lgErr" hidden></p><div class="modal-foot"><button type="button" class="btn ghost" data-act="forgot">Forgot password</button><button class="btn primary" type="submit">'+esc(T('login'))+'</button></div></form><p class="lead" style="margin:16px 0 0;font-size:13px">Preview only. Accounts are kept in this browser until Supabase Auth is connected in Phase 2. Passwords are never stored here.</p>','sm');
  }else{
    var det=(navigator.language||'').split('-')[1];det=det?det.toUpperCase():'BD';
    openModal('<h2>'+esc(T('signup'))+'</h2><p class="lead">Free for readers and reporters in every country.</p>'+(note?'<p class="note">'+esc(note)+'</p>':'')+'<form id="signupForm" novalidate>'+fieldHTML('suUser','Username','text','autocomplete="username" maxlength="24" required')+fieldHTML('suEmail','Email','email','autocomplete="email" required')+fieldHTML('suPass','Password','password','autocomplete="new-password" minlength="8" required')+
    '<div class="row2"><div class="field"><label for="suCountry">Country</label><select id="suCountry">'+countryOpts(det)+'</select></div><div class="field"><label for="suLang">Preferred language</label><select id="suLang">'+LANGS.map(function(l){return '<option value="'+l[0]+'"'+(l[0]===S.lang?' selected':'')+'>'+esc(l[2])+'</option>'}).join('')+'</select></div></div>'+
    '<div class="field"><label for="suPic">Profile picture (optional)</label><input id="suPic" type="file" accept="image/*"></div><div class="field"><label for="suBio">Biography (optional)</label><textarea id="suBio" style="min-height:70px" maxlength="240"></textarea></div><p class="err" id="suErr" hidden></p><div class="modal-foot"><button class="btn primary" type="submit">'+esc(T('signup'))+'</button></div></form><p class="lead" style="margin:16px 0 0;font-size:13px">We only ask for what the account needs. Preview only: nothing leaves this browser yet.</p>','sm');
  }
}
function setErr(id,msg){var e=$('#'+id);if(!e)return;e.textContent=msg;e.hidden=!msg}

/* publish */
function fmtSize(b){return b>1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB'}
function showPublish(){
  if(!S.user){showAuth('signup','Create a free account to publish. You can still publish anonymously afterwards.');return}
  S.files=[];S.reviewed=false;
  openModal('<h2>'+esc(T('publish'))+'</h2><p class="lead">Report what you know. Readers worldwide can translate it.</p><form id="pubForm" novalidate>'+
  '<div class="field"><label for="pTitle">Headline</label><input id="pTitle" maxlength="140" required placeholder="What happened, in one clear sentence"></div>'+
  '<div class="field"><label for="pBody">Full story</label><textarea id="pBody" required placeholder="Who, what, where, when. Say how you know."></textarea></div>'+
  '<div class="row2"><div class="field"><label for="pCountry">Country</label><select id="pCountry">'+countryOpts(S.user.country)+'</select></div><div class="field"><label for="pCat">Category</label><select id="pCat">'+TOPICS.map(function(c){return '<option value="'+c+'">'+esc(T(c))+'</option>'}).join('')+'</select></div></div>'+
  '<div class="field"><label for="pLoc">Location</label><input id="pLoc" maxlength="80" placeholder="Town, district or landmark"><small>Use a general area. Avoid exact home addresses.</small></div>'+
  '<div class="field"><label for="pFiles">Photos, videos, PDFs and evidence</label><input id="pFiles" type="file" multiple accept="image/*,video/*,application/pdf"><small>Up to 10 files, 25 MB each.</small><p class="err" id="fileMsg" hidden></p><ul class="files" id="fileList"></ul></div>'+
  '<span class="lbl">Publish as</span><div class="seg" style="margin-top:6px"><label><input type="radio" name="pMode" value="public" checked><span><b>'+esc(S.user.username)+'</b><small>Your public name and picture appear on the story.</small></span></label><label><input type="radio" name="pMode" value="anon"><span><b>'+esc(T('anon'))+'</b><small>No name or picture. Never in public URLs or data.</small></span></label></div>'+
  '<p class="note" id="anonNote" hidden>Anonymous protects your public identity. It cannot promise absolute anonymity: server logs, photo metadata and legal requests can still reveal information. We keep an account-level record for abuse prevention and legal compliance, with restricted access and audit logs.</p>'+
  '<div id="reviewBox" hidden></div><p class="err" id="pubErr" hidden></p><div class="modal-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary" type="submit" id="pubBtn">Review before publishing</button></div></form>');
}
function renderFiles(){
  $('#fileList').innerHTML=S.files.map(function(f,i){
    var th=f.type==='image'?'<img alt="" src="'+f.url+'">':ic(f.type==='pdf'?'file':'video');
    return '<li><span class="th">'+th+'</span><span style="min-width:0"><span class="nm" style="display:block">'+esc(f.name)+'</span><small>'+fmtSize(f.size)+'</small></span><button type="button" class="btn sm" data-act="rmfile" data-i="'+i+'">Remove</button></li>'}).join('');
}
function scanText(txt){
  var w=[];
  if(/(\+?\d[\d\s().-]{7,}\d)/.test(txt))w.push('A phone number appears in the text. Remove it unless it is a public helpline.');
  if(/[\w.+-]+@[\w-]+\.[\w.-]+/.test(txt))w.push('An email address appears in the text.');
  if(/\b\d{1,5}\s+[A-Za-z][\w\s]{2,30}\b(street|st|road|rd|avenue|ave|lane|ln|block|sector)\b/i.test(txt)||/\b(house|flat|apartment|holding)\s*(no\.?|#)?\s*\d+/i.test(txt))w.push('This looks like a street address. Use a general area instead.');
  if(/\b(nid|passport|national id|license|licence|ssn|tax id)\b[^.]{0,25}\d{5,}/i.test(txt)||/\b\d{10,17}\b/.test(txt))w.push('A long number that may be an ID or account number appears in the text.');
  return w;
}
function reviewStep(){
  var title=$('#pTitle').value.trim(),body=$('#pBody').value.trim();
  if(title.length<10)return 'Write a headline of at least 10 characters.';
  if(body.length<40)return 'Write at least 40 characters in the full story.';
  var anon=$('input[name=pMode]:checked').value==='anon';
  var w=scanText(title+' '+body+' '+$('#pLoc').value);
  var imgs=S.files.some(function(f){return f.type==='image'||f.type==='video'}),pdf=S.files.some(function(f){return f.type==='pdf'});
  if(imgs)w.push('Check every photo and video for faces, house numbers, vehicle plates and identity documents. Blur them or remove the file.');
  if(pdf)w.push('Documents can hold names, ID numbers and signatures. Open each one and redact private details.');
  if(imgs&&anon)w.push('Photos can carry GPS location and device details. Remove metadata before uploading if you publish anonymously.');
  var h='<div class="review"><b>'+(w.length?'Please check before publishing':'<span class="ok">No sensitive details found</span>')+'</b>';
  if(w.length)h+='<ul>'+w.map(function(x){return '<li>'+esc(x)+'</li>'}).join('')+'</ul><label style="display:flex;gap:8px;margin-top:10px;font-weight:500"><input type="checkbox" id="ack"> I reviewed the text and my media</label>';
  h+='<p class="lead" style="margin:10px 0 0;font-size:13px">This is an automatic check and can miss things. Uploaded media is listed above so you can remove files.</p></div>';
  var rb=$('#reviewBox');rb.innerHTML=h;rb.hidden=false;rb.setAttribute('data-warn',w.length);
  S.reviewed=true;$('#pubBtn').textContent='Publish story';
  return '';
}
function doPublish(){
  var anon=$('input[name=pMode]:checked').value==='anon';
  var a={id:nextId++,cat:$('#pCat').value,cc:$('#pCountry').value,loc:$('#pLoc').value.trim()||cname($('#pCountry').value),at:Date.now(),m:0,likes:0,community:1,t:$('#pTitle').value.trim(),s:$('#pBody').value.trim(),
    photo:S.files.some(function(f){return f.type==='image'||f.type==='video'})?1:0,files:S.files.map(function(f){return {name:f.name,type:f.type}})};
  if(anon){a.anon=1}else{a.author=S.user.username;if(S.user.avatar)a.avatar=S.user.avatar}
  A.unshift(a);S.comments[a.id]=[];
  S.files.forEach(function(f){if(f.url)try{URL.revokeObjectURL(f.url)}catch(e){}});
  S.files=[];closeModal();S.cat='all';S.q='';$('#q').value='';renderAll();window.scrollTo({top:0});
  toast(anon?'Published as Anonymous Reporter.':'Story published.');
}

/* report */
function showReport(id){
  var rs=['Fake news','Harassment','Defamation','Dangerous misinformation','Privacy violation','Harmful or illegal content'];
  openModal('<h2>Report this story</h2><p class="lead">Moderators review every report.</p><form id="reportForm" data-id="'+id+'"><div class="reasons">'+rs.map(function(r,i){return '<label><input type="radio" name="rr" value="'+esc(r)+'"'+(i===0?' checked':'')+'>'+esc(r)+'</label>'}).join('')+'</div><div class="field"><label for="rNote">Details (optional)</label><textarea id="rNote" style="min-height:80px"></textarea></div><div class="modal-foot"><button type="button" class="btn" data-act="back" data-id="'+id+'">Cancel</button><button class="btn primary" type="submit">Send report</button></div></form>','sm');
}

/* ---------- events ---------- */
document.addEventListener('click',function(e){
  var b=e.target.closest('[data-act]');
  if(!b){if(e.target===$('#overlay'))closeModal();return}
  var act=b.dataset.act,id=b.dataset.id?+b.dataset.id:null;
  switch(act){
    case 'cat':S.cat=b.dataset.cat;S.q='';$('#q').value='';$('#drawer').hidden=true;$('[data-act=menu]').setAttribute('aria-expanded','false');renderAll();window.scrollTo({top:0});break;
    case 'search':S.q=b.dataset.q;$('#q').value=S.q;renderAll();window.scrollTo({top:0});break;
    case 'menu':var d=$('#drawer');d.hidden=!d.hidden;b.setAttribute('aria-expanded',String(!d.hidden));break;
    case 'open':showArticle(id,b.dataset.focus==='comment');break;
    case 'like':
      var i=S.liked.indexOf(id);if(i>-1)S.liked.splice(i,1);else S.liked.push(id);store.set('liked',S.liked);
      var oid=S.openId;renderMain();renderBreaking();if(oid)showArticle(oid);break;
    case 'translate':showPicker('translate',id);break;
    case 'original':delete S.tr[id];renderMain();renderBreaking();if(S.openId)showArticle(S.openId);break;
    case 'lang':showPicker('display');break;
    case 'pl':
      if(!S.pick)break;S.pick.sel=b.dataset.l;
      if(S.pick.mode==='display'){closeModal();setLang(b.dataset.l)}else renderLangList();break;
    case 'dotranslate':
      var p=S.pick;if(!p||!p.sel)break;S.tLang=p.sel;store.set('tlang',p.sel);
      if(TR[p.id]&&TR[p.id][p.sel]){S.tr[p.id]=p.sel;var back=p.back;S.pick=null;renderMain();renderBreaking();if(back)showArticle(back);else closeModal();toast('Translated to '+lname(p.sel)[1]+'. Original text is preserved.')}
      else toast(lname(p.sel)[1]+' arrives with the translation API in Phase 7. Try Spanish or Bengali for now.');
      break;
    case 'pickcancel':if(S.pick&&S.pick.back)showArticle(S.pick.back);else closeModal();break;
    case 'close':closeModal();break;
    case 'login':showAuth('login');break;
    case 'signup':showAuth('signup');break;
    case 'logout':S.user=null;store.set('user',null);renderNav();applyLang();toast('You are logged out.');break;
    case 'forgot':toast('Password recovery goes live when Supabase Auth is connected in Phase 2.');break;
    case 'publish':$('#drawer').hidden=true;showPublish();break;
    case 'rmfile':var f=S.files.splice(+b.dataset.i,1)[0];if(f&&f.url)try{URL.revokeObjectURL(f.url)}catch(x){}renderFiles();S.reviewed=false;$('#reviewBox').hidden=true;$('#pubBtn').textContent='Review before publishing';break;
    case 'report':showReport(id);break;
    case 'back':showArticle(id);break;
  }
});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!$('#overlay').hidden)closeModal()});
document.addEventListener('input',function(e){
  var t=e.target;
  if(t.id==='q'){S.q=t.value.trim();renderNav();renderMain()}
  else if(t.id==='langSearch')renderLangList();
  else if(t.closest&&t.closest('#pubForm')&&t.id!=='ack'&&t.id!=='pFiles'){S.reviewed=false;var rb=$('#reviewBox');if(rb)rb.hidden=true;var pb=$('#pubBtn');if(pb)pb.textContent='Review before publishing';var an=$('#anonNote');if(an)an.hidden=$('input[name=pMode]:checked').value!=='anon'}
});
document.addEventListener('change',function(e){
  var t=e.target;
  if(t.name==='pMode'){$('#anonNote').hidden=t.value!=='anon';S.reviewed=false;$('#reviewBox').hidden=true;$('#pubBtn').textContent='Review before publishing'}
  if(t.id==='pFiles'){
    var msg='';
    Array.prototype.forEach.call(t.files,function(f){
      var type=/^image\//.test(f.type)?'image':/^video\//.test(f.type)?'video':f.type==='application/pdf'?'pdf':'';
      if(!type){msg='Skipped '+f.name+': only photos, videos and PDFs are accepted.';return}
      if(f.size>25*1048576){msg='Skipped '+f.name+': files must be 25 MB or smaller.';return}
      if(S.files.length>=10){msg='Only 10 files are allowed per story.';return}
      S.files.push({name:f.name,size:f.size,type:type,url:type==='image'?URL.createObjectURL(f):''});
    });
    t.value='';setErr('fileMsg',msg);renderFiles();S.reviewed=false;$('#reviewBox').hidden=true;$('#pubBtn').textContent='Review before publishing';
  }
});
document.addEventListener('submit',function(e){
  e.preventDefault();var f=e.target;
  if(f.id==='loginForm'){
    var em=$('#lgEmail').value.trim().toLowerCase(),pw=$('#lgPass').value;
    if(!em||!pw)return setErr('lgErr','Enter your email and password.');
    var saved=store.get('user',null);
    if(saved&&saved.email===em){S.user=saved;closeModal();renderNav();applyLang();toast('Welcome back, '+saved.username+'.')}
    else setErr('lgErr','No account for that email on this device. Sign up first.');
  }
  else if(f.id==='signupForm'){
    var u=$('#suUser').value.trim(),m=$('#suEmail').value.trim().toLowerCase(),p=$('#suPass').value;
    if(!/^[A-Za-z0-9_.]{3,24}$/.test(u))return setErr('suErr','Username needs 3 to 24 letters, numbers, dots or underscores.');
    if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(m))return setErr('suErr','Enter a valid email address.');
    if(p.length<8)return setErr('suErr','Password needs at least 8 characters.');
    var user={username:u,email:m,country:$('#suCountry').value,lang:$('#suLang').value,bio:$('#suBio').value.trim()};
    var finish=function(av){if(av)user.avatar=av;S.user=user;var keep={username:u,email:m,country:user.country,lang:user.lang,bio:user.bio};store.set('user',keep);
      closeModal();if(user.lang!==S.lang)setLang(user.lang);else{renderNav();applyLang()}toast('Account created. Welcome, '+u+'.')};
    var file=$('#suPic').files[0];
    if(file&&/^image\//.test(file.type)&&file.size<2097152){var r=new FileReader();r.onload=function(){finish(r.result)};r.onerror=function(){finish()};r.readAsDataURL(file)}else finish();
  }
  else if(f.id==='pubForm'){
    setErr('pubErr','');
    if(!S.reviewed){var er=reviewStep();if(er)setErr('pubErr',er);else $('#reviewBox').scrollIntoView({block:'nearest'});return}
    var rb=$('#reviewBox');if(+rb.getAttribute('data-warn')>0&&!$('#ack').checked)return setErr('pubErr','Tick the box to confirm you reviewed the warnings.');
    doPublish();
  }
  else if(f.id==='cmForm'){
    if(!S.user){showAuth('login','Log in to comment.');return}
    var tx=$('#cmText').value.trim();if(!tx)return;var cid=+f.dataset.id;
    S.comments[cid].push({n:S.user.username,t:tx,at:Date.now()});renderMain();showArticle(cid);
  }
  else if(f.id==='reportForm'){
    var rid=+f.dataset.id;showArticle(rid);toast('Report saved in this preview. The moderation queue goes live in Phase 8.');
  }
});

/* ---------- language suggestion ---------- */
function suggest(){
  if(store.get('lang',null))return;
  var nl=(navigator.language||'en'),base=nl.split('-')[0].toLowerCase(),reg=(nl.split('-')[1]||'').toUpperCase();
  var L=lname(base);if(!L||base==='en')return;
  var el=$('#suggest');
  el.innerHTML='<div class="wrap"><p>Your browser is set to '+esc(L[1])+(reg?' ('+esc(cname(reg))+')':'')+'. Switch the site to '+esc(L[2])+'?</p><button class="btn sm primary" data-act="sugyes">Switch to '+esc(L[2])+'</button><button class="btn sm" data-act="sugno">Keep English</button></div>';
  el.hidden=false;
  el.addEventListener('click',function(e){
    var b=e.target.closest('[data-act]');if(!b)return;
    if(b.dataset.act==='sugyes')setLang(base);else store.set('lang','en');
    el.hidden=true;
  });
}

applyLang();renderAll();suggest();
})();
