# OpenWorld Global News (Phase 1)

Static frontend: `index.html`, `styles.css`, `app.js`, plus `assets/`.

## Deploy on GitHub Pages
1. Create a repository and upload the contents of this folder to its root.
2. Settings > Pages > Source: "Deploy from a branch", branch `main`, folder `/ (root)`.
3. The site appears at `https://<user>.github.io/<repo>/`.

Fonts load from Google Fonts. Sample stories are fictional, and accounts, posts, likes and comments are stored only in the visitor's browser until the Supabase backend is added.
